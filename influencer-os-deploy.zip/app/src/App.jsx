import { useState, useEffect, useRef } from "react";
import {
  Sparkles, User, Plus, Trash2, Wand2, Loader2, ChevronRight, ChevronLeft,
  Image as ImageIcon, BookOpen, Layers, Clapperboard, Globe, Mic, Star, Cpu, Copy,
  BarChart3, TrendingUp, Target, CheckCircle2, CircleDashed, Send, Settings
} from "lucide-react";

/* ============================== Helpers ============================== */

// Motor-Einstellungen (Standard: Gemini gratis). Im Prototyp ohne Backend läuft der eingebaute Claude.
let _brain = { engine: "gemini", claudeModel: "sonnet", backendUrl: "" };
function setBrain(s) { _brain = { ..._brain, ...s }; }

async function callClaudeBuiltin(messages) {
  const res = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ model: "claude-sonnet-4-20250514", max_tokens: 1000, messages }),
  });
  if (!res.ok) throw new Error("API " + res.status);
  const data = await res.json();
  return (data.content || []).map((b) => (b.type === "text" ? b.text : "")).filter(Boolean).join("\n");
}

function reportBrainError(msg) {
  try { window.dispatchEvent(new CustomEvent("brain-error", { detail: msg })); } catch (_) {}
}

// Router: mit Backend-URL -> gewählter Motor (Gemini/Claude) übers Backend; Fehler werden sichtbar gemeldet
async function callClaude(messages) {
  try {
    if (!_brain.backendUrl) throw new Error('Keine Backend-URL gesetzt — oben unter „Motor" eintragen.');
    const u = messages.find((m) => m.role === "user");
    const prompt = typeof u?.content === "string" ? u.content : JSON.stringify(u?.content || "");
    let res;
    try {
      res = await fetch(_brain.backendUrl.replace(/\/+$/, "") + "/api/text", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ prompt, provider: _brain.engine === "claude" ? "claude" : "gemini", model: _brain.claudeModel }),
      });
    } catch (e) {
      throw new Error("Backend nicht erreichbar (Netzwerk/CORS): " + String(e.message || e));
    }
    if (!res.ok) {
      let msg = "Backend " + res.status;
      try { const d = await res.json(); if (d && d.error) msg += ": " + d.error; } catch (_) {}
      throw new Error(msg);
    }
    const d = await res.json();
    const out = typeof d === "string" ? d : (d.result ?? d.text ?? "");
    if (!out) throw new Error("Leere Antwort vom Backend.");
    return out;
  } catch (e) {
    reportBrainError(String(e.message || e));
    throw e;
  }
}

function parseJSON(text) {
  let t = (text || "").trim().replace(/^```json/i, "").replace(/^```/, "").replace(/```$/, "").trim();
  const s = t.search(/[\[{]/); if (s > 0) t = t.slice(s);
  const e = Math.max(t.lastIndexOf("}"), t.lastIndexOf("]")); if (e >= 0) t = t.slice(0, e + 1);
  try {
    return JSON.parse(t);
  } catch (err) {
    reportBrainError("Antwort war kein gültiges JSON — bitte nochmal generieren.");
    throw err;
  }
}

function fileToResizedDataURL(file, maxDim = 820, q = 0.82) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const img = new Image();
      img.onload = () => {
        let { width, height } = img;
        if (width > height && width > maxDim) { height = (height * maxDim) / width; width = maxDim; }
        else if (height > maxDim) { width = (width * maxDim) / height; height = maxDim; }
        const c = document.createElement("canvas");
        c.width = Math.round(width); c.height = Math.round(height);
        c.getContext("2d").drawImage(img, 0, 0, c.width, c.height);
        resolve(c.toDataURL("image/jpeg", q));
      };
      img.onerror = reject; img.src = e.target.result;
    };
    reader.onerror = reject; reader.readAsDataURL(file);
  });
}

const hasStore = typeof window !== "undefined" && window.storage && typeof window.storage.set === "function";
async function loadCharacters() {
  if (!hasStore) return [];
  try {
    const r = await window.storage.list("char:"); if (!r || !r.keys) return [];
    const out = [];
    for (const k of r.keys) { try { const g = await window.storage.get(k); if (g && g.value) out.push(JSON.parse(g.value)); } catch (_) {} }
    return out.sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
  } catch (_) { return []; }
}
async function persistChar(c) { if (hasStore) { try { await window.storage.set("char:" + c.id, JSON.stringify(c)); } catch (_) {} } }
async function removeChar(id) { if (hasStore) { try { await window.storage.delete("char:" + id); } catch (_) {} } }

const uid = (p) => p + Date.now().toString(36) + Math.random().toString(36).slice(2, 5);
const clone = (o) => JSON.parse(JSON.stringify(o));

const LANGS = ["Deutsch", "English", "Español", "Français", "Italiano"];
const MODES = [{ v: "saga", l: "Saga (fortlaufend)" }, { v: "standalone", l: "Standalone (Einzelszenen)" }, { v: "mix", l: "Mischung" }];
const PLATFORMS = ["TikTok", "Instagram", "Beide"];

const newCharacter = () => ({
  id: uid("c_"), createdAt: Date.now(), prompt: "",
  bp: { name: "", tagline: "", identity: "", personality: "", voice: "", values: [], niche: "", audience: "", contentPillars: [], brandFeel: "" },
  visual: { halfbody: { image: "", character: "", description: "" }, fullbody: { image: "", character: "", description: "" } },
  voiceAnchor: { name: "", voiceId: "", notes: "" },
  galaxies: [],
});

/* ============================== Styles ============================== */

const Styles = () => (
  <style>{`
    @import url('https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:opsz,wght@12..96,400;12..96,500;12..96,700&family=Plus+Jakarta+Sans:wght@400;500;600&display=swap');
    .ios * { box-sizing: border-box; }
    /* ===== Design-Tokens (theme-ready: Light-Mode spaeter via .ios[data-theme=light]) ===== */
    .ios {
      --bg:#16140e; --panel:#211d16; --panel2:#2b261d; --raised:#332d23;
      --line:rgba(255,255,255,.09); --line2:rgba(255,255,255,.17); --field:rgba(255,255,255,.13);
      --text:#f4efe3; --muted:#b4a98f; --faint:#8d8472;
      --accent:#e8a13a; --accent-press:#cf8826; --accent2:#e2674a; --gxy:#a99bff; --stf:#5fc9c0;
      --success:#7bb37e; --good:#7bb37e; --warning:#e8b53a; --danger:#e57058;
      --r-control:10px; --r-card:14px; --r-lg:18px;
      --dur-1:120ms; --dur-2:180ms; --ease:cubic-bezier(.2,.6,.2,1); --ring:0 0 0 2px var(--bg),0 0 0 4px var(--accent);
      font-family:'Plus Jakarta Sans',sans-serif; color:var(--text); background:var(--bg);
      min-height:700px; border-radius:14px; overflow:hidden; line-height:1.5;
      -webkit-tap-highlight-color:transparent; -webkit-font-smoothing:antialiased; text-rendering:optimizeLegibility;
    }
    .ios h1,.ios h2,.ios h3,.ios .disp { font-family:'Bricolage Grotesque',serif; font-weight:700; letter-spacing:-.015em; line-height:1.15; }
    .ios h1{font-size:26px;} .ios h2{font-size:20px;} .ios h3{font-size:16px;}
    .ios ::-webkit-scrollbar{width:10px;height:10px;}
    .ios ::-webkit-scrollbar-thumb{background:var(--line2);border-radius:10px;border:3px solid transparent;background-clip:padding-box;}
    .ios button{font-family:inherit;cursor:pointer;}
    .ios button:focus-visible,.ios a:focus-visible,.ios [tabindex]:focus-visible{outline:none;box-shadow:var(--ring);}
    /* ===== Buttons ===== */
    .btn{display:inline-flex;align-items:center;justify-content:center;gap:8px;border-radius:var(--r-control);border:1px solid var(--line2);background:transparent;color:var(--text);padding:9px 15px;font-size:14px;font-weight:600;line-height:1;transition:background var(--dur-1) var(--ease),border-color var(--dur-1) var(--ease),transform var(--dur-1) var(--ease);}
    .btn:hover{background:rgba(255,255,255,.06);} .btn:active{transform:scale(.97);} .btn:disabled{opacity:.4;cursor:not-allowed;}
    .btn-pri{background:var(--accent);color:#1c1606;border-color:transparent;} .btn-pri:hover{background:#f0ad48;} .btn-pri:active{background:var(--accent-press);}
    .btn-ghost{border-color:transparent;color:var(--muted);padding:8px 10px;} .btn-ghost:hover{color:var(--text);background:rgba(255,255,255,.06);}
    .btn-icon{padding:0;width:38px;height:38px;}
    .btn-danger{color:var(--danger);border-color:transparent;} .btn-danger:hover{background:rgba(229,112,88,.14);color:var(--danger);}
    /* ===== Fields ===== */
    .inp,.ta,.sel{width:100%;background:var(--bg);border:1px solid var(--field);border-radius:var(--r-control);color:var(--text);font-family:inherit;font-size:14px;padding:11px 13px;transition:border-color var(--dur-1) var(--ease),box-shadow var(--dur-1) var(--ease);resize:vertical;}
    .inp:focus,.ta:focus,.sel:focus{outline:none;border-color:var(--accent);box-shadow:0 0 0 3px rgba(232,161,58,.16);}
    .inp::placeholder,.ta::placeholder{color:var(--faint);}
    .lbl{font-size:11px;font-weight:600;text-transform:uppercase;letter-spacing:.07em;color:var(--muted);margin-bottom:6px;display:block;}
    /* ===== Surfaces ===== */
    .card{background:var(--panel);border:1px solid var(--line);border-radius:var(--r-card);}
    .card-raised{background:var(--raised);border:1px solid var(--line2);border-radius:var(--r-card);box-shadow:0 10px 30px -12px rgba(0,0,0,.55);}
    /* ===== Pills / Badges ===== */
    .pill{font-size:11px;font-weight:600;padding:4px 10px;border-radius:999px;background:var(--panel2);border:1px solid var(--line);color:var(--muted);white-space:nowrap;}
    .pill-success{color:var(--success);border-color:rgba(123,179,126,.4);background:rgba(123,179,126,.12);}
    .pill-warn{color:var(--warning);border-color:rgba(232,181,58,.4);background:rgba(232,181,58,.12);}
    .pill-danger{color:var(--danger);border-color:rgba(229,112,88,.4);background:rgba(229,112,88,.12);}
    /* ===== Motion ===== */
    .fade{animation:fade var(--dur-2) var(--ease) both;} @keyframes fade{from{opacity:0;transform:translateY(6px);}to{opacity:1;transform:none;}}
    .spin{animation:spin 1s linear infinite;} @keyframes spin{to{transform:rotate(360deg);}}
    /* ===== Rows ===== */
    .row{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:13px 15px;border:1px solid var(--line);border-radius:12px;background:var(--panel);transition:border-color var(--dur-1) var(--ease),background var(--dur-1) var(--ease);cursor:pointer;}
    .row:hover{border-color:var(--line2);background:var(--panel2);}
    .tree-row{transition:background var(--dur-1) var(--ease);} .tree-row:hover{background:var(--panel2);}
    .crumb{color:var(--muted);font-size:13px;font-weight:600;cursor:pointer;transition:color var(--dur-1) var(--ease);} .crumb:hover{color:var(--text);}
    .crumb.active{color:var(--text);cursor:default;}
    /* ===== Grids ===== */
    .grid{display:grid;gap:16px;}
    .cols-2{grid-template-columns:1fr 1fr;}
    .cols-3{grid-template-columns:repeat(3,1fr);}
    .cols-4{grid-template-columns:repeat(4,1fr);gap:12px;}
    .cols-side{grid-template-columns:180px 1fr;}
    .cols-lead{grid-template-columns:1fr 180px 200px;}
    .cards{grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:12px;}
    /* ===== App-Shell ===== */
    .appbar{position:sticky;top:0;z-index:20;padding:calc(12px + env(safe-area-inset-top)) 22px 12px;border-bottom:1px solid var(--line);background:rgba(33,29,22,.78);-webkit-backdrop-filter:saturate(170%) blur(18px);backdrop-filter:saturate(170%) blur(18px);}
    .content{padding:22px;padding-left:calc(22px + env(safe-area-inset-left));padding-right:calc(22px + env(safe-area-inset-right));padding-bottom:calc(28px + env(safe-area-inset-bottom));}
    .name-row{display:flex;gap:10px;align-items:center;}
    .name-row .grow{flex:1;min-width:0;}
    @media (max-width:720px){
      .cols-2,.cols-3,.cols-side,.cols-lead{grid-template-columns:1fr;}
      .cols-4{grid-template-columns:1fr 1fr;}
      .appbar{padding-left:16px;padding-right:16px;}
      .content{padding:16px;padding-bottom:calc(24px + env(safe-area-inset-bottom));}
      .inp,.ta,.sel{font-size:16px;}
      .btn{min-height:44px;} .btn-icon{width:44px;height:44px;}
      .name-row{flex-direction:column;align-items:stretch;}
    }
    @media (prefers-reduced-motion: reduce){.fade,.spin{animation:none;}}
  `}</style>
);

/* ============================== Small UI ============================== */

function Field({ label, value, onChange, rows = 2, placeholder, mono }) {
  return (
    <div style={{ marginBottom: 12 }}>
      <label className="lbl">{label}</label>
      <textarea className="ta" rows={rows} value={value || ""} placeholder={placeholder}
        onChange={(e) => onChange(e.target.value)} style={mono ? { fontSize: 13 } : null} />
    </div>
  );
}
function ListField({ label, value, onChange, placeholder }) {
  return (
    <div style={{ marginBottom: 12 }}>
      <label className="lbl">{label}</label>
      <input className="inp" value={(value || []).join(", ")} placeholder={placeholder}
        onChange={(e) => onChange(e.target.value.split(",").map((s) => s.trim()).filter(Boolean))} />
    </div>
  );
}
function BlueprintEditor({ bp, schema, onChange }) {
  const set = (k, v) => onChange({ ...(bp || {}), [k]: v });
  return (
    <div>
      {schema.map((f) =>
        f.type === "list"
          ? <ListField key={f.key} label={f.label} value={bp?.[f.key]} placeholder={f.ph} onChange={(v) => set(f.key, v)} />
          : <Field key={f.key} label={f.label} value={bp?.[f.key]} rows={f.rows || 2} placeholder={f.ph} onChange={(v) => set(f.key, v)} />
      )}
    </div>
  );
}

function CopyBlock({ label, value, accent, copied, onCopy }) {
  if (!value) return null;
  return (
    <div style={{ marginBottom: 10 }}>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 4 }}>
        <span className="lbl" style={{ margin: 0, color: accent ? "var(--accent)" : "var(--muted)" }}>{label}</span>
        <button className="btn btn-ghost" style={{ padding: "3px 8px", fontSize: 12 }} onClick={onCopy}>
          {copied
            ? <span style={{ display: "inline-flex", alignItems: "center", gap: 4 }}><svg width="12" height="12" viewBox="0 0 10 10"><path d="M2 5l2 2 4-5" fill="none" stroke="var(--good)" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" /></svg>Kopiert</span>
            : <span style={{ display: "inline-flex", alignItems: "center", gap: 4 }}><Copy size={12} />Kopieren</span>}
        </button>
      </div>
      <div style={{ background: "var(--bg)", border: "1px solid var(--line)", borderRadius: 10, padding: "10px 12px", fontSize: 13, lineHeight: 1.5, whiteSpace: "pre-wrap", color: "var(--text)" }}>{value}</div>
    </div>
  );
}

/* ============================== App ============================== */

export default function App() {
  const [characters, setCharacters] = useState([]);
  const [loaded, setLoaded] = useState(false);
  const [path, setPath] = useState({}); // {charId, galaxyId, staffelId, szeneId}
  const [settings, setSettings] = useState({ engine: "gemini", claudeModel: "sonnet", backendUrl: "" });
  const [showSettings, setShowSettings] = useState(false);
  const [brainError, setBrainError] = useState("");

  useEffect(() => {
    const h = (e) => setBrainError(String(e.detail || "Unbekannter Fehler"));
    window.addEventListener("brain-error", h);
    return () => window.removeEventListener("brain-error", h);
  }, []);
  useEffect(() => {
    if (!brainError) return;
    const t = setTimeout(() => setBrainError(""), 8000);
    return () => clearTimeout(t);
  }, [brainError]);

  useEffect(() => { loadCharacters().then((c) => { setCharacters(c); setLoaded(true); }); }, []);
  useEffect(() => {
    if (!hasStore) return;
    window.storage.get("settings").then((g) => { if (g && g.value) { const s = JSON.parse(g.value); setSettings(s); setBrain(s); } }).catch(() => {});
  }, []);
  useEffect(() => { setBrain(settings); }, [settings]);

  const updateSettings = (patch) => {
    const next = { ...settings, ...patch };
    setSettings(next); setBrain(next);
    if (hasStore) { try { window.storage.set("settings", JSON.stringify(next)); } catch (_) {} }
  };

  const saveChar = (c) => {
    setCharacters((prev) => (prev.some((x) => x.id === c.id) ? prev.map((x) => (x.id === c.id ? c : x)) : [c, ...prev]));
    persistChar(c);
  };
  const delChar = (id) => { removeChar(id); setCharacters((prev) => prev.filter((x) => x.id !== id)); setPath({}); };

  const char = characters.find((c) => c.id === path.charId) || null;
  const galaxy = char && char.galaxies.find((g) => g.id === path.galaxyId) || null;
  const staffel = galaxy && galaxy.staffeln.find((s) => s.id === path.staffelId) || null;
  const szene = staffel && staffel.szenen.find((z) => z.id === path.szeneId) || null;

  return (
    <div className="ios">
      <Styles />
      <Header path={path} char={char} galaxy={galaxy} staffel={staffel} szene={szene} go={setPath}
        settings={settings} onSettings={() => setShowSettings((v) => !v)} />
      <div className="content">
        {!settings.backendUrl && (
          <div className="card" style={{ padding: "12px 15px", marginBottom: 16, borderColor: "var(--accent2)", background: "rgba(226,103,74,.10)", fontSize: 13, color: "var(--text)" }}>
            <b style={{ color: "var(--accent2)" }}>Kein Backend verbunden.</b> Trage oben unter „Motor" deine Backend-URL ein, damit die Generierung läuft (siehe Anleitung).
          </div>
        )}
        {showSettings && <SettingsPanel settings={settings} update={updateSettings} onClose={() => setShowSettings(false)} />}
        {!path.charId && <CharacterList characters={characters} loaded={loaded}
          onNew={() => { const c = newCharacter(); saveChar(c); setPath({ charId: c.id }); }}
          onOpen={(id) => setPath({ charId: id })} onDelete={delChar} />}
        {char && !galaxy && !path.kpi && <CharacterView char={char} saveChar={saveChar}
          openGalaxy={(gId) => setPath({ charId: char.id, galaxyId: gId })}
          openStaffel={(gId, sId) => setPath({ charId: char.id, galaxyId: gId, staffelId: sId })}
          openSzene={(gId, sId, zId) => setPath({ charId: char.id, galaxyId: gId, staffelId: sId, szeneId: zId })}
          openKpi={() => setPath({ charId: char.id, kpi: true })} />}
        {char && !galaxy && path.kpi && <KpiDashboard char={char} saveChar={saveChar}
          openScene={(gId, sId, zId) => setPath({ charId: char.id, galaxyId: gId, staffelId: sId, szeneId: zId })} />}
        {char && galaxy && !staffel && <GalaxyView char={char} galaxy={galaxy} saveChar={saveChar}
          openStaffel={(id) => setPath({ ...path, staffelId: id })} />}
        {char && galaxy && staffel && !szene && <StaffelView char={char} galaxy={galaxy} staffel={staffel} saveChar={saveChar}
          openSzene={(id) => setPath({ ...path, szeneId: id })} />}
        {char && galaxy && staffel && szene && <SzeneView char={char} galaxy={galaxy} staffel={staffel} szene={szene} characters={characters} saveChar={saveChar} />}
      </div>
      {brainError && (
        <div className="card-raised fade" style={{ position: "fixed", left: 16, right: 16, bottom: "calc(16px + env(safe-area-inset-bottom))", zIndex: 50, padding: "12px 14px", borderColor: "var(--danger)", display: "flex", gap: 10, alignItems: "flex-start" }}>
          <span style={{ color: "var(--danger)", fontWeight: 700, flexShrink: 0 }}>!</span>
          <div style={{ fontSize: 13, lineHeight: 1.45, minWidth: 0, wordBreak: "break-word" }}>{brainError}</div>
          <button className="btn btn-ghost" style={{ padding: "2px 8px", flexShrink: 0 }} onClick={() => setBrainError("")} aria-label="Schließen">✕</button>
        </div>
      )}
    </div>
  );
}

const ENGINES = [
  { v: "gemini", l: "Gemini (gratis · Standard)" },
  { v: "claude", l: "Claude (optional)" },
];
const CLAUDE_MODELS = [
  { v: "haiku", l: "Haiku 4.5 — am günstigsten" },
  { v: "sonnet", l: "Sonnet 4.6 — ausgewogen" },
  { v: "opus", l: "Opus — am stärksten" },
];

function SettingsPanel({ settings, update, onClose }) {
  return (
    <div className="card-raised fade" style={{ padding: 18, marginBottom: 18 }}>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 14 }}>
        <h3 style={{ margin: 0, fontSize: 15, display: "flex", alignItems: "center", gap: 8 }}><Cpu size={15} style={{ color: "var(--accent)" }} /> Motor des Gehirns</h3>
        <button className="btn btn-ghost" onClick={onClose}>Schließen</button>
      </div>
      <div className="grid cols-2">
        <div>
          <label className="lbl">Motor</label>
          <select className="sel" value={settings.engine} onChange={(e) => update({ engine: e.target.value })} style={{ appearance: "auto" }}>
            {ENGINES.map((m) => <option key={m.v} value={m.v}>{m.l}</option>)}
          </select>
        </div>
        {settings.engine === "claude" && (
          <div>
            <label className="lbl">Claude-Modell</label>
            <select className="sel" value={settings.claudeModel} onChange={(e) => update({ claudeModel: e.target.value })} style={{ appearance: "auto" }}>
              {CLAUDE_MODELS.map((m) => <option key={m.v} value={m.v}>{m.l}</option>)}
            </select>
          </div>
        )}
      </div>
      <div style={{ marginTop: 12 }}>
        <label className="lbl">Backend-URL (fürs Deployment)</label>
        <input className="inp" value={settings.backendUrl} placeholder="https://dein-backend… (leer = Prototyp)"
          onChange={(e) => update({ backendUrl: e.target.value })} />
      </div>
      <div style={{ marginTop: 12, fontSize: 12.5, color: "var(--muted)", lineHeight: 1.5 }}>
        Trage die URL deines Backends ein (siehe Anleitung) — es hält deinen Gemini-Schlüssel sicher server-seitig.
        Aktiver Motor: {settings.engine === "gemini" ? "Gemini (gratis)" : "Claude"}.
      </div>
    </div>
  );
}

/* ============================== Header / Breadcrumb ============================== */

function Header({ path, char, galaxy, staffel, szene, go, settings, onSettings }) {
  const crumbs = [{ label: "Charaktere", to: {} }];
  if (char) crumbs.push({ label: char.bp?.name || "Charakter", to: { charId: char.id } });
  if (path?.kpi && char) crumbs.push({ label: "KPI & Optimierung", to: { charId: char.id, kpi: true } });
  if (galaxy) crumbs.push({ label: galaxy.name || "Buch", to: { charId: char.id, galaxyId: galaxy.id } });
  if (staffel) crumbs.push({ label: staffel.name || "Kapitel", to: { charId: char.id, galaxyId: galaxy.id, staffelId: staffel.id } });
  if (szene) crumbs.push({ label: szene.name || "Szene", to: { charId: char.id, galaxyId: galaxy.id, staffelId: staffel.id, szeneId: szene.id } });

  const engineLabel = settings?.engine === "claude" ? "Claude" : "Gemini";

  return (
    <div className="appbar">
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: 12, marginBottom: crumbs.length > 1 ? 10 : 0 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          <div style={{ width: 32, height: 32, borderRadius: 9, background: "var(--accent)", display: "grid", placeItems: "center", color: "#1a1505" }}>
            <Sparkles size={18} />
          </div>
          <div>
            <div className="disp" style={{ fontSize: 15, lineHeight: 1 }}>Influencer OS</div>
            <div style={{ fontSize: 10.5, color: "var(--faint)", marginTop: 2 }}>Phase 1 · Gehirn-Kern</div>
          </div>
        </div>
        <button className="btn btn-ghost" onClick={onSettings} style={{ gap: 6 }} title="Motor wählen">
          <Cpu size={15} /> <span style={{ fontSize: 12.5 }}>Motor: {engineLabel}</span>
        </button>
      </div>
      {crumbs.length > 1 && (
        <div style={{ display: "flex", alignItems: "center", gap: 6, flexWrap: "wrap" }}>
          {crumbs.map((c, i) => (
            <span key={i} style={{ display: "flex", alignItems: "center", gap: 6 }}>
              {i > 0 && <ChevronRight size={13} style={{ color: "var(--faint)" }} />}
              <span className={"crumb" + (i === crumbs.length - 1 ? " active" : "")}
                onClick={() => i < crumbs.length - 1 && go(c.to)}>{c.label}</span>
            </span>
          ))}
        </div>
      )}
    </div>
  );
}

/* ============================== Character List ============================== */

function CharacterList({ characters, loaded, onNew, onOpen, onDelete }) {
  return (
    <div className="fade">
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 18 }}>
        <div>
          <h1 style={{ fontSize: 22, margin: 0 }}>Charaktere</h1>
          <p style={{ color: "var(--muted)", fontSize: 14, margin: "4px 0 0" }}>Das Fundament jedes Universums.</p>
        </div>
        <button className="btn btn-pri" onClick={onNew}><Plus size={17} /> Neuer Charakter</button>
      </div>
      {!loaded ? <div style={{ textAlign: "center", padding: 40, color: "var(--muted)" }}><Loader2 size={20} className="spin" /></div>
        : characters.length === 0 ? (
          <div className="card" style={{ padding: 40, textAlign: "center" }}>
            <User size={26} style={{ color: "var(--accent)" }} />
            <h3 style={{ margin: "12px 0 6px" }}>Noch kein Charakter</h3>
            <p style={{ color: "var(--muted)", fontSize: 14, marginBottom: 16 }}>Lege deinen ersten Charakter an — darauf bauen alle Bücher, Kapitel und Szenen auf.</p>
            <button className="btn btn-pri" onClick={onNew} style={{ margin: "0 auto" }}><Plus size={17} /> Anlegen</button>
          </div>
        ) : (
          <div className="grid cards">
            {characters.map((c) => (
              <div key={c.id} className="card" style={{ overflow: "hidden", display: "flex", flexDirection: "column" }}>
                <div style={{ height: 140, background: "var(--bg)" }}>
                  {(c.visual?.halfbody?.image || c.visual?.fullbody?.image)
                    ? <img src={c.visual.halfbody.image || c.visual.fullbody.image} alt="" style={{ width: "100%", height: "100%", objectFit: "cover" }} />
                    : <div style={{ display: "grid", placeItems: "center", height: "100%", color: "var(--faint)" }}><ImageIcon size={24} /></div>}
                </div>
                <div style={{ padding: 14, flex: 1, display: "flex", flexDirection: "column" }}>
                  <div className="disp" style={{ fontSize: 16 }}>{c.bp?.name || "Unbenannt"}</div>
                  <div style={{ fontSize: 12, color: "var(--muted)", margin: "3px 0 10px", flex: 1 }}>
                    {(c.galaxies?.length || 0)} {c.galaxies?.length === 1 ? "Buch" : "Bücher"} · {c.bp?.niche || "—"}
                  </div>
                  <div style={{ display: "flex", gap: 6 }}>
                    <button className="btn" style={{ flex: 1, justifyContent: "center", padding: "7px 0" }} onClick={() => onOpen(c.id)}>Öffnen <ChevronRight size={15} /></button>
                    <button className="btn btn-icon btn-danger" aria-label="Charakter löschen" onClick={() => onDelete(c.id)}><Trash2 size={16} /></button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      {!hasStore && <p style={{ color: "var(--faint)", fontSize: 12, marginTop: 16 }}>Hinweis: Kein persistenter Speicher verfügbar — Daten bleiben nur in dieser Sitzung.</p>}
    </div>
  );
}

/* ============================== Character View ============================== */

const CHAR_SCHEMA = [
  { key: "tagline", label: "USP / Tagline", rows: 2 },
  { key: "identity", label: "Identität & Story", rows: 3 },
  { key: "personality", label: "Persönlichkeit", rows: 3 },
  { key: "voice", label: "Sprache & Tonalität", rows: 2 },
  { key: "values", label: "Werte", type: "list", ph: "Wert 1, Wert 2 …" },
  { key: "niche", label: "Nische / Positionierung", rows: 2 },
  { key: "audience", label: "Zielgruppe", rows: 2 },
  { key: "contentPillars", label: "Content-Säulen", type: "list", ph: "Säule 1, Säule 2 …" },
  { key: "brandFeel", label: "Bildsprache / Markenwirkung", rows: 2 },
];

function CharacterView({ char, saveChar, openGalaxy, openStaffel, openSzene, openKpi }) {
  const [gen, setGen] = useState(false);
  const [openBooks, setOpenBooks] = useState({});
  const [openChaps, setOpenChaps] = useState({});
  const [showDetails, setShowDetails] = useState(false);
  const toggleBook = (id) => setOpenBooks((s) => ({ ...s, [id]: !s[id] }));
  const toggleChap = (id) => setOpenChaps((s) => ({ ...s, [id]: !s[id] }));
  const setBP = (bp) => saveChar({ ...char, bp });
  const setVisual = (visual) => saveChar({ ...char, visual });
  const setVoice = (voiceAnchor) => saveChar({ ...char, voiceAnchor });

  const generate = async () => {
    if (!char.prompt.trim()) return;
    setGen(true);
    try {
      const out = await callClaude([{ role: "user", content:
        "Du bist ein KI-Influencer-Strategiesystem. Erstelle aus dieser Idee ein vollständiges, individuelles Charakter-Blueprint.\nIdee: \"" + char.prompt.trim() + "\"\n" +
        "Antworte AUSSCHLIESSLICH mit gültigem JSON (kein Markdown): " +
        '{"name":"","tagline":"","identity":"","personality":"","voice":"","values":["",""],"niche":"","audience":"","contentPillars":["","",""],"brandFeel":""}. ' +
        "Alle Texte auf Deutsch, konkret und einzigartig, keine Floskeln." }]);
      const j = parseJSON(out);
      setBP({ name: j.name || char.bp.name, tagline: j.tagline || "", identity: j.identity || "", personality: j.personality || "", voice: j.voice || "",
        values: j.values || [], niche: j.niche || "", audience: j.audience || "", contentPillars: j.contentPillars || [], brandFeel: j.brandFeel || "" });
    } catch (_) {} finally { setGen(false); }
  };

  const addGalaxy = () => {
    const g = { id: uid("g_"), createdAt: Date.now(), name: "Neues Buch", language: "Deutsch", mode: "mix", idea: "", bp: null, staffeln: [] };
    saveChar({ ...char, galaxies: [...char.galaxies, g] });
    openGalaxy(g.id);
  };
  const addChapter = (galaxy) => {
    const s = { id: uid("s_"), createdAt: Date.now(), name: "Neues Kapitel", idea: "", bp: null, szenen: [] };
    saveChar({ ...char, galaxies: char.galaxies.map((x) => (x.id === galaxy.id ? { ...x, staffeln: [...x.staffeln, s] } : x)) });
    openStaffel(galaxy.id, s.id);
  };
  const addScene = (galaxy, staffel) => {
    const z = { id: uid("z_"), createdAt: Date.now(), name: "Neue Szene", idea: "", platform: "Beide", lengthSec: 30, voiceOver: false, rueckblick: [], gaeste: [], bp: null };
    saveChar({ ...char, galaxies: char.galaxies.map((x) => (x.id === galaxy.id ? { ...x, staffeln: x.staffeln.map((st) => (st.id === staffel.id ? { ...st, szenen: [...st.szenen, z] } : st)) } : x)) });
    openSzene(galaxy.id, staffel.id, z.id);
  };

  const Chevron = ({ open }) => <ChevronRight size={16} style={{ color: "var(--faint)", flexShrink: 0, transition: "transform .15s", transform: open ? "rotate(90deg)" : "none" }} />;
  const Node = ({ level, icon, name, sub, expandable, open, onClick, onGear }) => (
    <div className="tree-row" onClick={onClick} style={{ display: "flex", alignItems: "center", gap: 10, padding: "11px 12px", paddingLeft: 12 + level * 18, borderRadius: 10, cursor: "pointer", minHeight: 50 }}>
      {expandable ? <Chevron open={open} /> : <span style={{ width: 16, flexShrink: 0 }} />}
      {icon}
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontWeight: 600, fontSize: 14.5, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{name}</div>
        {sub && <div style={{ fontSize: 11.5, color: "var(--muted)" }}>{sub}</div>}
      </div>
      <button className="btn btn-ghost" onClick={(e) => { e.stopPropagation(); onGear(); }} style={{ padding: 8, flexShrink: 0 }} aria-label="Bearbeiten"><Settings size={16} /></button>
    </div>
  );
  const AddRow = ({ level, label, onClick }) => (
    <button onClick={onClick} style={{ display: "flex", alignItems: "center", gap: 8, width: "100%", padding: "10px 12px", paddingLeft: 12 + level * 18, marginTop: 2, border: "1px dashed var(--line2)", background: "transparent", borderRadius: 10, color: "var(--muted)", fontSize: 13.5, fontWeight: 600, minHeight: 44 }}>
      <Plus size={15} /> {label}
    </button>
  );

  return (
    <div className="fade">
      <div className="name-row" style={{ marginBottom: 16 }}>
        <input className="inp grow" value={char.bp.name} placeholder="Charaktername"
          onChange={(e) => setBP({ ...char.bp, name: e.target.value })}
          style={{ fontSize: 19, fontWeight: 600, fontFamily: "'Bricolage Grotesque',serif" }} />
        <button className="btn" onClick={openKpi} style={{ whiteSpace: "nowrap" }}><BarChart3 size={16} /> KPI & Optimierung</button>
      </div>

      <div style={{ display: "flex", alignItems: "center", gap: 8, margin: "4px 2px 10px" }}>
        <BookOpen size={17} style={{ color: "var(--gxy)" }} />
        <h3 style={{ margin: 0, fontSize: 16 }}>Bücher · Kapitel · Szenen</h3>
      </div>
      <div className="card" style={{ padding: 8, marginBottom: 18 }}>
        {char.galaxies.length === 0 && (
          <div style={{ padding: "14px 12px", color: "var(--muted)", fontSize: 13.5 }}>Noch kein Buch. Lege dein erstes an — jedes Buch ist ein eigenes Story-Universum.</div>
        )}
        {char.galaxies.map((g) => (
          <div key={g.id}>
            <Node level={0} icon={<BookOpen size={17} style={{ color: "var(--gxy)", flexShrink: 0 }} />}
              name={g.name} sub={g.staffeln.length + " Kapitel · " + g.language}
              expandable open={!!openBooks[g.id]} onClick={() => toggleBook(g.id)} onGear={() => openGalaxy(g.id)} />
            {openBooks[g.id] && (<>
              {g.staffeln.map((s) => (
                <div key={s.id}>
                  <Node level={1} icon={<Layers size={16} style={{ color: "var(--stf)", flexShrink: 0 }} />}
                    name={s.name} sub={s.szenen.length + " Szenen"}
                    expandable open={!!openChaps[s.id]} onClick={() => toggleChap(s.id)} onGear={() => openStaffel(g.id, s.id)} />
                  {openChaps[s.id] && (<>
                    {s.szenen.map((z) => (
                      <Node key={z.id} level={2} icon={<Clapperboard size={15} style={{ color: "var(--accent)", flexShrink: 0 }} />}
                        name={z.name} sub={z.platform + " · " + z.lengthSec + "s" + (z.voiceOver ? " · VO" : "")}
                        expandable={false} onClick={() => openSzene(g.id, s.id, z.id)} onGear={() => openSzene(g.id, s.id, z.id)} />
                    ))}
                    <AddRow level={2} label="Szene hinzufügen" onClick={() => addScene(g, s)} />
                  </>)}
                </div>
              ))}
              <AddRow level={1} label="Kapitel hinzufügen" onClick={() => addChapter(g)} />
            </>)}
          </div>
        ))}
        <AddRow level={0} label="Buch hinzufügen" onClick={addGalaxy} />
      </div>

      {/* Charakter-Steckbrief (einklappbar) */}
      <button className="btn" onClick={() => setShowDetails((v) => !v)} style={{ width: "100%", justifyContent: "space-between", marginBottom: showDetails ? 16 : 0 }}>
        <span style={{ display: "flex", alignItems: "center", gap: 8 }}><Star size={15} style={{ color: "var(--accent)" }} /> Charakter-Steckbrief {char.bp?.name ? "bearbeiten" : "anlegen"}</span>
        <ChevronRight size={16} style={{ transition: "transform .15s", transform: showDetails ? "rotate(90deg)" : "none" }} />
      </button>
      {showDetails && (
        <div className="grid cols-2 fade">
          {/* Blueprint */}
          <div className="card" style={{ padding: 18 }}>
            <h3 style={{ margin: "0 0 12px", fontSize: 15, display: "flex", alignItems: "center", gap: 8 }}><Star size={15} style={{ color: "var(--accent)" }} /> Charakter-Blueprint</h3>
            <label className="lbl">Idee (ein Satz)</label>
            <div style={{ display: "flex", gap: 8, marginBottom: 14 }}>
              <input className="inp" value={char.prompt} placeholder="z.B. 25-j. Fitness-Coachin, direkt & motivierend"
                onChange={(e) => saveChar({ ...char, prompt: e.target.value })} onKeyDown={(e) => e.key === "Enter" && generate()} />
              <button className="btn btn-pri" disabled={gen || !char.prompt.trim()} onClick={generate} style={{ whiteSpace: "nowrap" }}>
                {gen ? <Loader2 size={15} className="spin" /> : <Wand2 size={15} />}{gen ? "…" : "Gen."}
              </button>
            </div>
            <BlueprintEditor bp={char.bp} schema={CHAR_SCHEMA} onChange={setBP} />
          </div>

          {/* Visual + Voice anchor */}
          <div style={{ display: "flex", flexDirection: "column", gap: 18 }}>
            <div className="card" style={{ padding: 18 }}>
              <h3 style={{ margin: "0 0 4px", fontSize: 15, display: "flex", alignItems: "center", gap: 8 }}><ImageIcon size={15} style={{ color: "var(--accent)" }} /> Visueller Anker</h3>
              <p style={{ color: "var(--muted)", fontSize: 12, margin: "0 0 14px" }}>Bild hochladen, dann Character & Description manuell darunter eintragen.</p>
              <ImageSlot label="Halfbody-Bild" slot="halfbody" visual={char.visual} setVisual={setVisual} />
              <ImageSlot label="Fullbody-Bild" slot="fullbody" visual={char.visual} setVisual={setVisual} />
            </div>
            <div className="card" style={{ padding: 18 }}>
              <h3 style={{ margin: "0 0 4px", fontSize: 15, display: "flex", alignItems: "center", gap: 8 }}><Mic size={15} style={{ color: "var(--accent)" }} /> Stimm-Anker</h3>
              <p style={{ color: "var(--muted)", fontSize: 12, margin: "0 0 14px" }}>Geklonte Stimme (ElevenLabs) — hält die Stimme über alle Videos identisch.</p>
              <div className="grid cols-2">
                <div><label className="lbl">Stimm-Name</label><input className="inp" value={char.voiceAnchor.name} placeholder="z.B. Mara DE" onChange={(e) => setVoice({ ...char.voiceAnchor, name: e.target.value })} /></div>
                <div><label className="lbl">ElevenLabs Voice-ID</label><input className="inp" value={char.voiceAnchor.voiceId} placeholder="voice_…" onChange={(e) => setVoice({ ...char.voiceAnchor, voiceId: e.target.value })} /></div>
              </div>
              <div style={{ marginTop: 10 }}><label className="lbl">Stimm-Regie (Standard)</label><input className="inp" value={char.voiceAnchor.notes} placeholder="z.B. warm, ruhig, leicht energetisch" onChange={(e) => setVoice({ ...char.voiceAnchor, notes: e.target.value })} /></div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function ImageSlot({ label, slot, visual, setVisual }) {
  const fileRef = useRef(null);
  const data = visual[slot];
  const set = (patch) => setVisual({ ...visual, [slot]: { ...data, ...patch } });
  const onPick = async (e) => { const f = e.target.files?.[0]; if (!f) return; try { set({ image: await fileToResizedDataURL(f) }); } catch (_) {} };
  return (
    <div style={{ marginBottom: 16, paddingTop: 14, borderTop: "1px solid var(--line)" }}>
      <label className="lbl">{label}</label>
      <button onClick={() => fileRef.current?.click()} style={{ width: "100%", height: 140, borderRadius: 10, border: "1px dashed var(--line2)", background: "var(--bg)", overflow: "hidden", display: "grid", placeItems: "center", color: "var(--faint)", padding: 0, marginBottom: 12 }}>
        {data.image ? <img src={data.image} alt="" style={{ width: "100%", height: "100%", objectFit: "cover" }} /> : <div style={{ textAlign: "center", fontSize: 12 }}><Plus size={22} /><div style={{ marginTop: 4 }}>Bild hochladen</div></div>}
      </button>
      <input ref={fileRef} type="file" accept="image/*" onChange={onPick} style={{ display: "none" }} />
      <div style={{ marginBottom: 10 }}><label className="lbl" style={{ marginBottom: 4 }}>Character</label><textarea className="ta" rows={2} value={data.character || ""} placeholder="Fixe Aussehensmerkmale…" onChange={(e) => set({ character: e.target.value })} /></div>
      <div><label className="lbl" style={{ marginBottom: 4 }}>Description</label><textarea className="ta" rows={3} value={data.description || ""} placeholder="Detaillierte Bildbeschreibung…" onChange={(e) => set({ description: e.target.value })} /></div>
    </div>
  );
}

/* ============================== Galaxy View ============================== */

const GALAXY_SCHEMA = [
  { key: "kern", label: "Kern", rows: 2, ph: "Die zentrale Idee dieses Buchs" },
  { key: "signatur", label: "Signatur (wiedererkennbar)", rows: 2, ph: "Was in jeder Szene durchscheint" },
  { key: "praemisse", label: "Prämisse", rows: 2 },
  { key: "ton", label: "Ton & Stimmung", rows: 2 },
  { key: "wiederkehrend", label: "Wiederkehrende Elemente", type: "list", ph: "Orte, Requisiten, Motive …" },
];

function GalaxyView({ char, galaxy, saveChar, openStaffel }) {
  const [gen, setGen] = useState(false);
  const update = (patch) => saveChar({ ...char, galaxies: char.galaxies.map((g) => (g.id === galaxy.id ? { ...g, ...patch } : g)) });

  const generate = async () => {
    setGen(true);
    try {
      const out = await callClaude([{ role: "user", content:
        "Charakter-Blueprint (JSON):\n" + JSON.stringify(char.bp) + "\n\n" +
        "Erstelle das Blueprint für eine 'Galaxy' (ein eigenständiges Story-/Inhalts-Universum dieses Charakters).\n" +
        "Idee: \"" + (galaxy.idea || "").trim() + "\" · Modus: " + galaxy.mode + " · Sprache der Inhalte: " + galaxy.language + "\n" +
        "Antworte AUSSCHLIESSLICH mit JSON: " +
        '{"kern":"","signatur":"","praemisse":"","ton":"","wiederkehrend":["",""]}. ' +
        "signatur = das wiedererkennbare Markenzeichen, das in jeder Szene durchscheint. Texte in " + galaxy.language + ", konkret, keine Floskeln." }]);
      update({ bp: parseJSON(out) });
    } catch (_) {} finally { setGen(false); }
  };

  const addStaffel = () => {
    const s = { id: uid("s_"), createdAt: Date.now(), name: "Neues Kapitel", idea: "", bp: null, szenen: [] };
    update({ staffeln: [...galaxy.staffeln, s] });
    openStaffel(s.id);
  };

  return (
    <div className="fade">
      <input className="inp" value={galaxy.name} placeholder="Buch-Name"
        onChange={(e) => update({ name: e.target.value })}
        style={{ fontSize: 19, fontWeight: 600, fontFamily: "'Bricolage Grotesque',serif", marginBottom: 16 }} />

      <div className="card" style={{ padding: 18, marginBottom: 22 }}>
        <h3 style={{ margin: "0 0 14px", fontSize: 15, display: "flex", alignItems: "center", gap: 8 }}><BookOpen size={15} style={{ color: "var(--gxy)" }} /> Galaxy-Blueprint</h3>
        <div className="grid cols-lead" style={{ marginBottom: 12, alignItems: "end" }}>
          <div><label className="lbl">Idee</label><input className="inp" value={galaxy.idea} placeholder="Worum geht es in diesem Buch?" onChange={(e) => update({ idea: e.target.value })} /></div>
          <div><label className="lbl"><Globe size={11} style={{ verticalAlign: "-1px" }} /> Sprache</label>
            <select className="sel" value={galaxy.language} onChange={(e) => update({ language: e.target.value })} style={{ appearance: "auto" }}>{LANGS.map((l) => <option key={l}>{l}</option>)}</select></div>
          <div><label className="lbl">Modus</label>
            <select className="sel" value={galaxy.mode} onChange={(e) => update({ mode: e.target.value })} style={{ appearance: "auto" }}>{MODES.map((m) => <option key={m.v} value={m.v}>{m.l}</option>)}</select></div>
        </div>
        <button className="btn btn-pri" disabled={gen} onClick={generate} style={{ marginBottom: galaxy.bp ? 16 : 0 }}>
          {gen ? <Loader2 size={15} className="spin" /> : <Wand2 size={15} />}{gen ? "Erzeuge…" : galaxy.bp ? "Neu generieren" : "Blueprint generieren"}
        </button>
        {galaxy.bp && <BlueprintEditor bp={galaxy.bp} schema={GALAXY_SCHEMA} onChange={(bp) => update({ bp })} />}
      </div>

      <div>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 12 }}>
          <h3 style={{ margin: 0, fontSize: 16, display: "flex", alignItems: "center", gap: 8 }}><Layers size={17} style={{ color: "var(--stf)" }} /> Kapitel (Staffeln)</h3>
          <button className="btn btn-pri" onClick={addStaffel}><Plus size={16} /> Kapitel</button>
        </div>
        {galaxy.staffeln.length === 0
          ? <div className="card" style={{ padding: 22, textAlign: "center", color: "var(--muted)", fontSize: 13.5 }}>Noch kein Kapitel.</div>
          : <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
              {galaxy.staffeln.map((s) => (
                <div key={s.id} className="row" onClick={() => openStaffel(s.id)}>
                  <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
                    <Layers size={16} style={{ color: "var(--stf)" }} />
                    <div><div style={{ fontWeight: 600, fontSize: 14.5 }}>{s.name}</div><div style={{ fontSize: 12, color: "var(--muted)" }}>{s.szenen.length} Szenen</div></div>
                  </div>
                  <ChevronRight size={17} style={{ color: "var(--faint)" }} />
                </div>
              ))}
            </div>}
      </div>
    </div>
  );
}

/* ============================== Staffel View ============================== */

const STAFFEL_SCHEMA = [
  { key: "bogen", label: "Spannungsbogen", rows: 2 },
  { key: "kontext", label: "Kontext (vertieft)", rows: 3 },
  { key: "roterFaden", label: "Roter Faden", rows: 2 },
  { key: "beats", label: "Schlüssel-Beats", type: "list", ph: "Beat 1, Beat 2 …" },
];

function StaffelView({ char, galaxy, staffel, saveChar, openSzene }) {
  const [gen, setGen] = useState(false);
  const update = (patch) => {
    const staffeln = galaxy.staffeln.map((s) => (s.id === staffel.id ? { ...s, ...patch } : s));
    saveChar({ ...char, galaxies: char.galaxies.map((g) => (g.id === galaxy.id ? { ...g, staffeln } : g)) });
  };
  const generate = async () => {
    setGen(true);
    try {
      const out = await callClaude([{ role: "user", content:
        "Charakter: " + (char.bp?.name || "") + "\nGalaxy-Kern: " + (galaxy.bp?.kern || "") + " · Signatur: " + (galaxy.bp?.signatur || "") + "\n" +
        "Erstelle das Blueprint für ein 'Kapitel' (Staffel) in dieser Galaxy. Idee: \"" + (staffel.idea || "").trim() + "\"\n" +
        "Antworte AUSSCHLIESSLICH mit JSON: " + '{"bogen":"","kontext":"","roterFaden":"","beats":["","",""]}. ' +
        "Texte in " + galaxy.language + ", konkret." }]);
      update({ bp: parseJSON(out) });
    } catch (_) {} finally { setGen(false); }
  };
  const addSzene = () => {
    const z = { id: uid("z_"), createdAt: Date.now(), name: "Neue Szene", idea: "", platform: "Beide", lengthSec: 30, voiceOver: false, rueckblick: [], gaeste: [], bp: null };
    update({ szenen: [...staffel.szenen, z] });
    openSzene(z.id);
  };

  return (
    <div className="fade">
      <input className="inp" value={staffel.name} placeholder="Kapitel-Name" onChange={(e) => update({ name: e.target.value })}
        style={{ fontSize: 19, fontWeight: 600, fontFamily: "'Bricolage Grotesque',serif", marginBottom: 16 }} />
      <div className="card" style={{ padding: 18, marginBottom: 22 }}>
        <h3 style={{ margin: "0 0 14px", fontSize: 15, display: "flex", alignItems: "center", gap: 8 }}><Layers size={15} style={{ color: "var(--stf)" }} /> Kapitel-Blueprint</h3>
        <div style={{ display: "flex", gap: 10, marginBottom: 12 }}>
          <input className="inp" value={staffel.idea} placeholder="Worum geht es in diesem Kapitel?" onChange={(e) => update({ idea: e.target.value })} />
          <button className="btn btn-pri" disabled={gen} onClick={generate} style={{ whiteSpace: "nowrap" }}>{gen ? <Loader2 size={15} className="spin" /> : <Wand2 size={15} />}{gen ? "…" : staffel.bp ? "Neu" : "Generieren"}</button>
        </div>
        {staffel.bp && <BlueprintEditor bp={staffel.bp} schema={STAFFEL_SCHEMA} onChange={(bp) => update({ bp })} />}
      </div>
      <div>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 12 }}>
          <h3 style={{ margin: 0, fontSize: 16, display: "flex", alignItems: "center", gap: 8 }}><Clapperboard size={17} style={{ color: "var(--accent)" }} /> Szenen (Ausführungen)</h3>
          <button className="btn btn-pri" onClick={addSzene}><Plus size={16} /> Szene</button>
        </div>
        {staffel.szenen.length === 0
          ? <div className="card" style={{ padding: 22, textAlign: "center", color: "var(--muted)", fontSize: 13.5 }}>Noch keine Szene. Jede Szene = eine Ausführung = ein Video-Paket.</div>
          : <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
              {staffel.szenen.map((z) => (
                <div key={z.id} className="row" onClick={() => openSzene(z.id)}>
                  <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
                    <Clapperboard size={16} style={{ color: "var(--accent)" }} />
                    <div><div style={{ fontWeight: 600, fontSize: 14.5 }}>{z.name}</div>
                      <div style={{ fontSize: 12, color: "var(--muted)" }}>{z.platform} · {z.lengthSec}s{z.voiceOver ? " · Voice-Over" : ""}</div></div>
                  </div>
                  <ChevronRight size={17} style={{ color: "var(--faint)" }} />
                </div>
              ))}
            </div>}
      </div>
    </div>
  );
}

/* ============================== Szene View ============================== */

const SZENE_SCHEMA = [
  { key: "konzept", label: "Konzept", rows: 3 },
  { key: "hook", label: "Hook", rows: 2 },
  { key: "beats", label: "Beats", type: "list", ph: "Beat 1, Beat 2 …" },
];

function SzeneView({ char, galaxy, staffel, szene, characters, saveChar }) {
  const [gen, setGen] = useState(false);
  const update = (patch) => {
    const szenen = staffel.szenen.map((z) => (z.id === szene.id ? { ...z, ...patch } : z));
    const staffeln = galaxy.staffeln.map((s) => (s.id === staffel.id ? { ...s, szenen } : s));
    saveChar({ ...char, galaxies: char.galaxies.map((g) => (g.id === galaxy.id ? { ...g, staffeln } : g)) });
  };
  const toggleIn = (key, id) => { const arr = szene[key] || []; update({ [key]: arr.includes(id) ? arr.filter((x) => x !== id) : [...arr, id] }); };
  const guests = characters.filter((c) => c.id !== char.id);

  const generate = async () => {
    setGen(true);
    try {
      const refs = (szene.rueckblick || []).map((id) => galaxy.staffeln.find((s) => s.id === id)).filter(Boolean).map((s) => s.name + ": " + (s.bp?.bogen || "")).join(" | ");
      const gs = (szene.gaeste || []).map((id) => characters.find((c) => c.id === id)?.bp?.name).filter(Boolean).join(", ");
      const out = await callClaude([{ role: "user", content:
        "Charakter: " + (char.bp?.name || "") + " · Galaxy-Signatur: " + (galaxy.bp?.signatur || "") + " · Kapitel-Bogen: " + (staffel.bp?.bogen || "") + "\n" +
        (refs ? "Rückblick auf: " + refs + "\n" : "") + (gs ? "Gast-Charaktere: " + gs + "\n" : "") +
        "Erstelle das Konzept für EINE Szene (1 Kurzvideo). Idee: \"" + (szene.idea || "").trim() + "\" · Plattform: " + szene.platform + " · Länge: " + szene.lengthSec + "s · Voice-Over: " + (szene.voiceOver ? "ja" : "nein") + "\n" +
        "Antworte AUSSCHLIESSLICH mit JSON: " + '{"konzept":"","hook":"","beats":["",""]}. ' + "Texte in " + galaxy.language + ". Bei fortlaufender Galaxy an den roten Faden anknüpfen." }]);
      update({ bp: parseJSON(out) });
    } catch (_) {} finally { setGen(false); }
  };

  const [outGen, setOutGen] = useState(false);
  const [copied, setCopied] = useState("");
  const copyText = (t, key) => { try { navigator.clipboard?.writeText(t || ""); } catch (_) {} setCopied(key); setTimeout(() => setCopied(""), 1300); };

  const anchorText = [char.visual?.halfbody?.character, char.visual?.halfbody?.description, char.visual?.fullbody?.character, char.visual?.fullbody?.description]
    .map((s) => (s || "").trim()).filter(Boolean).join(" · ");

  const generateOutput = async () => {
    setOutGen(true);
    try {
      const refs = (szene.rueckblick || []).map((id) => galaxy.staffeln.find((s) => s.id === id)).filter(Boolean).map((s) => s.name + ": " + (s.bp?.bogen || "")).join(" | ");
      const gs = (szene.gaeste || []).map((id) => characters.find((c) => c.id === id)).filter(Boolean).map((c) => c.bp?.name).filter(Boolean).join(", ");
      const ctx =
        "CHARAKTER: " + (char.bp?.name || "") + " — " + (char.bp?.voice || "") + "\n" +
        "VISUELLER ANKER (in jeden Bild-Prompt einbauen): " + (anchorText || "(keine Bilddaten hinterlegt)") + "\n" +
        "STIMM-ANKER: " + (char.voiceAnchor?.name || "—") + (char.voiceAnchor?.notes ? " (" + char.voiceAnchor.notes + ")" : "") + "\n" +
        "GALAXY-SIGNATUR: " + (galaxy.bp?.signatur || "") + " · TON: " + (galaxy.bp?.ton || "") + "\n" +
        "KAPITEL-BOGEN: " + (staffel.bp?.bogen || "") + "\n" +
        (refs ? "RÜCKBLICK: " + refs + "\n" : "") + (gs ? "GAST-CHARAKTERE: " + gs + "\n" : "") +
        "SZENEN-KONZEPT: " + (szene.bp?.konzept || szene.idea || "") + " · HOOK: " + (szene.bp?.hook || "") + "\n" +
        "PLATTFORM: " + szene.platform + " (9:16) · LÄNGE: " + szene.lengthSec + "s · SPRACHE GESPROCHENER/TEXT-INHALTE: " + galaxy.language + " · VOICE-OVER: " + (szene.voiceOver ? "JA" : "NEIN");

      const shotInstr =
        ctx + "\n\n" +
        "Erzeuge die Shot-Liste für dieses " + szene.lengthSec + "s-Video (Richtwert 1 Shot je 4–8 s, 3–6 Shots). " +
        "imagePrompt und videoPrompt auf ENGLISCH; voiceover und onscreen in " + galaxy.language + ".\n" +
        "imagePrompt: präziser Gemini-Bild-Prompt; beginne mit dem visuellen Anker (gleiche Person wie Referenzbild), 9:16, plus Negativ-Hinweise gegen Abweichung.\n" +
        (szene.voiceOver
          ? "Voice-Over AN: videoPrompt OHNE Dialog, lip-sync-tauglich (Gesicht sichtbar, frontal, ruhiger Mund, stabil); voiceover = gesprochener Text, ~2,5–3 Wörter/Sekunde auf die Shot-Dauer gerechnet.\n"
          : "Voice-Over AUS: kein Sprech-Fokus; videoPrompt frei nach Intention. Soll nativ gesprochen werden, Dialog direkt im videoPrompt als Character says: \"…\". voiceover leer lassen.\n") +
        "Antworte AUSSCHLIESSLICH mit JSON-Array: " +
        '[{"n":1,"duration":"0-5s","imagePrompt":"","videoPrompt":"","voiceover":"","onscreen":""}]. Knapp halten.';
      const shots = parseJSON(await callClaude([{ role: "user", content: shotInstr }]));

      const shotSummary = (shots || []).map((s) => s.n + ": " + s.duration + (s.onscreen ? " | OnScreen: " + s.onscreen : "")).join("\n");
      const wrapInstr =
        ctx + "\n\nSHOTS:\n" + shotSummary + "\n\n" +
        "Erzeuge den Rest des Pakets. cover.imagePrompt auf ENGLISCH (mit Anker), alle anderen Texte in " + galaxy.language + ". " +
        "caption/hashtags nach aktuellem Best-Practice (Hook in Zeile 1, klarer CTA, wenige gezielte Hashtags). " +
        "editSheet = kurze Schritt-Liste (Reihenfolge, wo VO/Text/Musik liegen, Übergänge, Hook-Sekunde).\n" +
        "Antworte AUSSCHLIESSLICH mit JSON: " +
        '{"subtitles":"","music":"","editSheet":["",""],"cover":{"imagePrompt":"","text":""},"caption":"","hashtags":["",""],"cta":"","kpi":{"hookType":"","pillar":""}}.';
      const wrap = parseJSON(await callClaude([{ role: "user", content: wrapInstr }]));

      update({ output: { shots, ...wrap, generatedAt: Date.now() } });
    } catch (_) {} finally { setOutGen(false); }
  };

  const fullBrief = (o) => {
    if (!o) return "";
    const L = [];
    L.push("SZENE: " + szene.name);
    if (szene.bp?.konzept) L.push("Konzept: " + szene.bp.konzept);
    if (szene.bp?.hook) L.push("Hook: " + szene.bp.hook);
    L.push("Format: " + szene.platform + " · 9:16 · " + szene.lengthSec + "s · " + galaxy.language);
    if (anchorText) L.push("Charakter-Anker: " + anchorText);
    L.push("");
    (o.shots || []).forEach((s, i) => {
      L.push("— SHOT " + (s.n ?? i + 1) + " (" + (s.duration || "") + ") —");
      L.push("Bild-Prompt (Gemini): " + (s.imagePrompt || ""));
      L.push("Video-Prompt (Flow/Dreamina): " + (s.videoPrompt || ""));
      if (s.voiceover) L.push("Voiceover (ElevenLabs): " + s.voiceover);
      if (s.onscreen) L.push("On-Screen: " + s.onscreen);
      L.push("");
    });
    L.push("Untertitel: " + (o.subtitles || ""));
    L.push("Musik: " + (o.music || ""));
    L.push("Edit-Sheet: " + (o.editSheet || []).join(" | "));
    L.push("Cover-Bild-Prompt: " + (o.cover?.imagePrompt || ""));
    L.push("Cover-Text: " + (o.cover?.text || ""));
    L.push("Caption: " + (o.caption || ""));
    L.push("Hashtags: " + (o.hashtags || []).join(" "));
    L.push("CTA: " + (o.cta || ""));
    return L.join("\n");
  };

  const Check = ({ on, onClick, children }) => (
    <button onClick={onClick} style={{ display: "flex", alignItems: "center", gap: 8, padding: "8px 12px", borderRadius: 9, fontSize: 13, fontWeight: 600,
      border: "1px solid " + (on ? "var(--accent)" : "var(--line)"), background: on ? "rgba(232,161,58,.12)" : "var(--bg)", color: "var(--text)" }}>
      <span style={{ width: 16, height: 16, borderRadius: 5, border: "1px solid " + (on ? "var(--accent)" : "var(--line2)"), background: on ? "var(--accent)" : "transparent", display: "grid", placeItems: "center", color: "#1a1505" }}>{on && <CheckIcon />}</span>
      {children}
    </button>
  );
  function CheckIcon() { return <Check2 />; }
  function Check2() { return <span style={{ display: "grid", placeItems: "center" }}><svg width="10" height="10" viewBox="0 0 10 10"><path d="M2 5l2 2 4-5" fill="none" stroke="#1a1505" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" /></svg></span>; }

  return (
    <div className="fade">
      <input className="inp" value={szene.name} placeholder="Szenen-Name" onChange={(e) => update({ name: e.target.value })}
        style={{ fontSize: 19, fontWeight: 600, fontFamily: "'Bricolage Grotesque',serif", marginBottom: 16 }} />

      <div className="card" style={{ padding: 18, marginBottom: 18 }}>
        <h3 style={{ margin: "0 0 14px", fontSize: 15, display: "flex", alignItems: "center", gap: 8 }}><Clapperboard size={15} style={{ color: "var(--accent)" }} /> Szenen-Steuerung</h3>
        <div style={{ marginBottom: 14 }}><label className="lbl">Handlung / Idee der Szene</label>
          <input className="inp" value={szene.idea} placeholder="Was passiert in dieser Szene?" onChange={(e) => update({ idea: e.target.value })} /></div>

        <div className="grid cols-side" style={{ marginBottom: 14, alignItems: "end" }}>
          <div><label className="lbl">Plattform</label>
            <select className="sel" value={szene.platform} onChange={(e) => update({ platform: e.target.value })} style={{ appearance: "auto" }}>{PLATFORMS.map((p) => <option key={p}>{p}</option>)}</select></div>
          <div><label className="lbl">Länge: {szene.lengthSec}s</label>
            <input type="range" min={5} max={60} step={5} value={szene.lengthSec} onChange={(e) => update({ lengthSec: Number(e.target.value) })}
              style={{ width: "100%", accentColor: "var(--accent)" }} /></div>
        </div>

        <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
          <Check on={szene.voiceOver} onClick={() => update({ voiceOver: !szene.voiceOver })}>Voice-Over</Check>
          <Check on={(szene.rueckblick || []).length > 0 || szene._rb} onClick={() => update({ _rb: !szene._rb })}>Rückblick</Check>
          <Check on={(szene.gaeste || []).length > 0 || szene._gs} onClick={() => update({ _gs: !szene._gs })}>Gast-Charakter</Check>
        </div>

        {(szene._rb || (szene.rueckblick || []).length > 0) && (
          <div style={{ marginTop: 12 }}><label className="lbl">Rückblick auf Kapitel</label>
            <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
              {galaxy.staffeln.filter((s) => s.id !== staffel.id).length === 0
                ? <span style={{ fontSize: 12.5, color: "var(--faint)" }}>Keine anderen Kapitel vorhanden.</span>
                : galaxy.staffeln.filter((s) => s.id !== staffel.id).map((s) => {
                    const on = (szene.rueckblick || []).includes(s.id);
                    return <button key={s.id} className="pill" onClick={() => toggleIn("rueckblick", s.id)}
                      style={{ cursor: "pointer", borderColor: on ? "var(--accent)" : "var(--line)", color: on ? "var(--text)" : "var(--muted)", background: on ? "rgba(232,161,58,.12)" : "var(--panel2)" }}>{s.name}</button>;
                  })}
            </div>
          </div>
        )}
        {(szene._gs || (szene.gaeste || []).length > 0) && (
          <div style={{ marginTop: 12 }}><label className="lbl">Gast-Charaktere</label>
            <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
              {guests.length === 0 ? <span style={{ fontSize: 12.5, color: "var(--faint)" }}>Keine anderen Charaktere vorhanden.</span>
                : guests.map((c) => {
                    const on = (szene.gaeste || []).includes(c.id);
                    return <button key={c.id} className="pill" onClick={() => toggleIn("gaeste", c.id)}
                      style={{ cursor: "pointer", borderColor: on ? "var(--accent)" : "var(--line)", color: on ? "var(--text)" : "var(--muted)", background: on ? "rgba(232,161,58,.12)" : "var(--panel2)" }}>{c.bp?.name || "Unbenannt"}</button>;
                  })}
            </div>
          </div>
        )}
      </div>

      <div className="card" style={{ padding: 18, marginBottom: 18 }}>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 14 }}>
          <h3 style={{ margin: 0, fontSize: 15, display: "flex", alignItems: "center", gap: 8 }}><Star size={15} style={{ color: "var(--accent)" }} /> Szenen-Konzept</h3>
          <button className="btn btn-pri" disabled={gen} onClick={generate}>{gen ? <Loader2 size={15} className="spin" /> : <Wand2 size={15} />}{gen ? "Erzeuge…" : szene.bp ? "Neu generieren" : "Konzept generieren"}</button>
        </div>
        {szene.bp ? <BlueprintEditor bp={szene.bp} schema={SZENE_SCHEMA} onChange={(bp) => update({ bp })} />
          : <p style={{ color: "var(--faint)", fontSize: 13.5, margin: 0 }}>Idee eintragen, Steuerung setzen, dann Konzept generieren.</p>}
      </div>

      <div className="card" style={{ padding: 18 }}>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 14, flexWrap: "wrap", gap: 8 }}>
          <h3 style={{ margin: 0, fontSize: 15, display: "flex", alignItems: "center", gap: 8 }}><Clapperboard size={15} style={{ color: "var(--accent)" }} /> Vollständiges Paket</h3>
          <div style={{ display: "flex", gap: 8 }}>
            {szene.output && <button className="btn" onClick={() => copyText(fullBrief(szene.output), "all")}>{copied === "all" ? "Kopiert ✓" : "Alles kopieren"}</button>}
            <button className="btn btn-pri" disabled={outGen} onClick={generateOutput}>{outGen ? <Loader2 size={15} className="spin" /> : <Wand2 size={15} />}{outGen ? "Baue Paket…" : szene.output ? "Neu generieren" : "Paket generieren"}</button>
          </div>
        </div>

        {!szene.output && !outGen && <p style={{ color: "var(--faint)", fontSize: 13.5, margin: 0 }}>
          Erzeugt Bild-Prompt, Video-Prompt, {szene.voiceOver ? "ElevenLabs-Skript, " : ""}Untertitel, Musik, Edit-Sheet, Cover und Caption — als getrennte Copy-Blöcke, fertig zum Einfügen in deine Tools.</p>}
        {outGen && !szene.output && <div style={{ color: "var(--muted)", textAlign: "center", padding: 18, fontSize: 14 }}><Loader2 size={18} className="spin" /><div style={{ marginTop: 6 }}>Shots, Skript und Verpackung…</div></div>}

        {szene.output && (
          <div className="fade">
            {anchorText && <div style={{ fontSize: 12, color: "var(--muted)", marginBottom: 14 }}><span style={{ color: "var(--accent)", fontWeight: 600 }}>Anker in allen Bild-Prompts: </span>{anchorText}</div>}
            {(szene.output.shots || []).map((s, i) => (
              <div key={i} className="card" style={{ padding: 14, marginBottom: 10, background: "var(--panel2)" }}>
                <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 10 }}>
                  <span className="disp" style={{ fontSize: 16, color: "var(--accent)" }}>Shot {s.n ?? i + 1}</span>
                  {s.duration && <span className="pill">{s.duration}</span>}
                </div>
                <CopyBlock label="Bild-Prompt (Gemini)" value={s.imagePrompt} accent copied={copied === "i" + i} onCopy={() => copyText(s.imagePrompt, "i" + i)} />
                <CopyBlock label="Video-Prompt (Flow / Dreamina)" value={s.videoPrompt} accent copied={copied === "v" + i} onCopy={() => copyText(s.videoPrompt, "v" + i)} />
                <CopyBlock label={"Voiceover (ElevenLabs" + (char.voiceAnchor?.name ? " · " + char.voiceAnchor.name : "") + ")"} value={s.voiceover} copied={copied === "vo" + i} onCopy={() => copyText(s.voiceover, "vo" + i)} />
                <CopyBlock label="On-Screen-Text" value={s.onscreen} copied={copied === "o" + i} onCopy={() => copyText(s.onscreen, "o" + i)} />
              </div>
            ))}
            <div style={{ borderTop: "1px solid var(--line)", margin: "4px 0 14px" }} />
            <CopyBlock label="Untertitel" value={szene.output.subtitles} copied={copied === "sub"} onCopy={() => copyText(szene.output.subtitles, "sub")} />
            <CopyBlock label="Musik / Sound" value={szene.output.music} copied={copied === "mus"} onCopy={() => copyText(szene.output.music, "mus")} />
            <CopyBlock label="Edit-Sheet" value={(szene.output.editSheet || []).join("\n")} copied={copied === "edit"} onCopy={() => copyText((szene.output.editSheet || []).join("\n"), "edit")} />
            <CopyBlock label="Cover-Bild-Prompt (Gemini)" value={szene.output.cover?.imagePrompt} accent copied={copied === "cov"} onCopy={() => copyText(szene.output.cover?.imagePrompt, "cov")} />
            <CopyBlock label="Cover-Text" value={szene.output.cover?.text} copied={copied === "covt"} onCopy={() => copyText(szene.output.cover?.text, "covt")} />
            <CopyBlock label="Caption" value={szene.output.caption} copied={copied === "cap"} onCopy={() => copyText(szene.output.caption, "cap")} />
            <CopyBlock label="Hashtags" value={(szene.output.hashtags || []).join(" ")} copied={copied === "hash"} onCopy={() => copyText((szene.output.hashtags || []).join(" "), "hash")} />
            <CopyBlock label="CTA" value={szene.output.cta} copied={copied === "cta"} onCopy={() => copyText(szene.output.cta, "cta")} />
            {szene.output.kpi && (szene.output.kpi.hookType || szene.output.kpi.pillar) && (
              <div style={{ display: "flex", gap: 6, marginTop: 8, flexWrap: "wrap" }}>
                {szene.output.kpi.hookType && <span className="pill">Hook-Typ: {szene.output.kpi.hookType}</span>}
                {szene.output.kpi.pillar && <span className="pill">Säule: {szene.output.kpi.pillar}</span>}
                <span className="pill">{szene.lengthSec}s · {szene.platform}</span>
              </div>
            )}
          </div>
        )}
      </div>

      <PerformanceCard szene={szene} update={update} />
    </div>
  );
}

/* ============================== KPI: Helpers ============================== */

const STATUS = [
  { v: "draft", l: "Entwurf", color: "var(--faint)" },
  { v: "produced", l: "Produziert", color: "var(--stf)" },
  { v: "published", l: "Veröffentlicht", color: "var(--good)" },
];
const num = (v) => { const n = Number(v); return isFinite(n) ? n : 0; };
const fmt = (n) => { n = num(n); return n >= 1000 ? (n / 1000).toFixed(n >= 10000 ? 0 : 1) + "k" : String(n); };
function engagementRate(m) {
  const v = num(m?.views);
  if (!v) return 0;
  return (num(m?.likes) + num(m?.comments) + num(m?.saves) + num(m?.shares)) / v;
}
function flattenScenes(char) {
  const out = [];
  (char.galaxies || []).forEach((g) => (g.staffeln || []).forEach((s) => (s.szenen || []).forEach((z) => out.push({ galaxy: g, staffel: s, szene: z }))));
  return out;
}

/* ============================== Performance card (in Szene) ============================== */

function PerformanceCard({ szene, update }) {
  const status = szene.status || "draft";
  const m = szene.metrics || {};
  const setM = (patch) => update({ metrics: { ...m, ...patch } });
  const er = engagementRate(m);
  const fields = [
    { k: "views", l: "Views" }, { k: "likes", l: "Likes" }, { k: "comments", l: "Kommentare" }, { k: "saves", l: "Saves" },
    { k: "shares", l: "Shares" }, { k: "watchPct", l: "Watch-Time %" }, { k: "follows", l: "Neue Follower" }, { k: "clicks", l: "Link-Klicks" },
  ];
  return (
    <div className="card" style={{ padding: 18 }}>
      <h3 style={{ margin: "0 0 14px", fontSize: 15, display: "flex", alignItems: "center", gap: 8 }}><TrendingUp size={15} style={{ color: "var(--accent)" }} /> Status & Performance</h3>
      <label className="lbl">Status</label>
      <div style={{ display: "flex", gap: 8, marginBottom: status === "published" ? 16 : 0, flexWrap: "wrap" }}>
        {STATUS.map((s) => {
          const on = status === s.v;
          return (
            <button key={s.v} onClick={() => update({ status: s.v })} style={{ display: "flex", alignItems: "center", gap: 7, padding: "8px 13px", borderRadius: 9, fontSize: 13, fontWeight: 600,
              border: "1px solid " + (on ? s.color : "var(--line)"), background: on ? "rgba(255,255,255,.05)" : "var(--bg)", color: on ? "var(--text)" : "var(--muted)" }}>
              {s.v === "published" ? <CheckCircle2 size={14} style={{ color: on ? s.color : "var(--faint)" }} /> : <CircleDashed size={14} style={{ color: on ? s.color : "var(--faint)" }} />}
              {s.l}
            </button>
          );
        })}
      </div>

      {status === "published" && (
        <div className="fade">
          <div className="grid cols-2" style={{ marginBottom: 14 }}>
            <div><label className="lbl">Veröffentlicht am</label><input className="inp" type="date" value={m.postedAt || ""} onChange={(e) => setM({ postedAt: e.target.value })} style={{ appearance: "auto" }} /></div>
            <div style={{ display: "flex", alignItems: "flex-end" }}>
              <div className="pill pill-success" style={{ fontSize: 12.5, padding: "8px 12px" }}>Engagement-Rate: {(er * 100).toFixed(1)}%</div>
            </div>
          </div>
          <div className="grid cols-4">
            {fields.map((f) => (
              <div key={f.k}>
                <label className="lbl" style={{ fontSize: 10.5 }}>{f.l}</label>
                <input className="inp" type="number" inputMode="numeric" value={m[f.k] ?? ""} placeholder="0" onChange={(e) => setM({ [f.k]: e.target.value })} style={{ padding: "9px 10px" }} />
              </div>
            ))}
          </div>
          <div style={{ marginTop: 12 }}><label className="lbl">Notizen</label><input className="inp" value={m.notes || ""} placeholder="Was lief gut/schlecht, Beobachtungen…" onChange={(e) => setM({ notes: e.target.value })} /></div>
        </div>
      )}
    </div>
  );
}

/* ============================== KPI Dashboard (Charakter-Ebene) ============================== */

function KpiDashboard({ char, saveChar, openScene }) {
  const [gen, setGen] = useState(false);
  const all = flattenScenes(char);
  const published = all.filter((x) => x.szene.status === "published");

  const totals = published.reduce((a, x) => {
    const m = x.szene.metrics || {};
    a.views += num(m.views); a.likes += num(m.likes); a.comments += num(m.comments);
    a.saves += num(m.saves); a.shares += num(m.shares); a.follows += num(m.follows); a.clicks += num(m.clicks);
    return a;
  }, { views: 0, likes: 0, comments: 0, saves: 0, shares: 0, follows: 0, clicks: 0 });
  const avgER = published.length ? published.reduce((a, x) => a + engagementRate(x.szene.metrics), 0) / published.length : 0;

  const byKey = (keyFn) => {
    const map = {};
    published.forEach((x) => {
      const k = (keyFn(x) || "—").trim() || "—";
      if (!map[k]) map[k] = { count: 0, views: 0, er: 0 };
      map[k].count++; map[k].views += num(x.szene.metrics?.views); map[k].er += engagementRate(x.szene.metrics);
    });
    return Object.entries(map).map(([k, v]) => ({ k, count: v.count, avgViews: v.views / v.count, avgER: v.er / v.count })).sort((a, b) => b.avgViews - a.avgViews);
  };
  const byPillar = byKey((x) => x.szene.output?.kpi?.pillar);
  const byHook = byKey((x) => x.szene.output?.kpi?.hookType);
  const topScenes = [...published].sort((a, b) => num(b.szene.metrics?.views) - num(a.szene.metrics?.views)).slice(0, 5);
  const opt = char.optimization;

  const optimize = async () => {
    setGen(true);
    try {
      const summary =
        "CHARAKTER: " + (char.bp?.name || "") + " · Nische: " + (char.bp?.niche || "") + "\n" +
        "Veröffentlichte Szenen: " + published.length + " · Views gesamt: " + totals.views + " · Ø Engagement: " + (avgER * 100).toFixed(1) + "% · Neue Follower: " + totals.follows + "\n" +
        "LEISTUNG NACH SÄULE (Ø Views, Ø Engagement, Anzahl):\n" + byPillar.map((p) => "- " + p.k + ": " + Math.round(p.avgViews) + " Views, " + (p.avgER * 100).toFixed(1) + "%, " + p.count + " Videos").join("\n") + "\n" +
        "LEISTUNG NACH HOOK-TYP:\n" + byHook.map((h) => "- " + h.k + ": " + Math.round(h.avgViews) + " Views, " + (h.avgER * 100).toFixed(1) + "%").join("\n") + "\n" +
        "TOP-SZENEN: " + topScenes.map((x) => x.szene.name + " (" + fmt(x.szene.metrics?.views) + " Views)").join(", ");
      const out = await callClaude([{ role: "user", content:
        summary + "\n\nDu bist der Performance-Stratege dieses Profils. Leite aus diesen echten Zahlen konkrete Schlüsse ab. " +
        "Antworte AUSSCHLIESSLICH mit JSON: " + '{"works":["",""],"cut":["",""],"nextIdeas":[{"title":"","why":""}],"cadence":""}. ' +
        "works = was nachweislich funktioniert; cut = was du stoppen oder ändern solltest; nextIdeas = 3 konkrete nächste Szenen-Ideen, die an die stärkste Säule und den stärksten Hook anknüpfen; cadence = Empfehlung zur Posting-Frequenz. Alles auf Deutsch, konkret und zahlenbezogen." }]);
      saveChar({ ...char, optimization: { ...parseJSON(out), generatedAt: Date.now() } });
    } catch (_) {} finally { setGen(false); }
  };

  const maxPillar = Math.max(1, ...byPillar.map((p) => p.avgViews));
  const maxHook = Math.max(1, ...byHook.map((h) => h.avgViews));
  const Tile = ({ label, value, sub }) => (
    <div className="card" style={{ padding: 14, background: "var(--panel2)" }}>
      <div style={{ fontSize: 11, color: "var(--muted)", textTransform: "uppercase", letterSpacing: ".06em", fontWeight: 600 }}>{label}</div>
      <div className="disp" style={{ fontSize: 24, marginTop: 4 }}>{value}</div>
      {sub && <div style={{ fontSize: 11.5, color: "var(--faint)", marginTop: 2 }}>{sub}</div>}
    </div>
  );
  const Bars = ({ rows, max }) => (
    <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
      {rows.map((r) => (
        <div key={r.k}>
          <div style={{ display: "flex", justifyContent: "space-between", fontSize: 12.5, marginBottom: 3 }}>
            <span style={{ color: "var(--text)" }}>{r.k}</span>
            <span style={{ color: "var(--muted)" }}>{fmt(Math.round(r.avgViews))} Ø Views · {(r.avgER * 100).toFixed(1)}%</span>
          </div>
          <div style={{ height: 8, borderRadius: 6, background: "var(--bg)", overflow: "hidden" }}>
            <div style={{ width: Math.max(4, (r.avgViews / max) * 100) + "%", height: "100%", background: "var(--accent)" }} />
          </div>
        </div>
      ))}
    </div>
  );

  return (
    <div className="fade">
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 18, flexWrap: "wrap", gap: 10 }}>
        <div>
          <h1 style={{ fontSize: 22, margin: 0, display: "flex", alignItems: "center", gap: 10 }}><BarChart3 size={22} style={{ color: "var(--accent)" }} /> KPI & Optimierung</h1>
          <p style={{ color: "var(--muted)", fontSize: 14, margin: "4px 0 0" }}>{char.bp?.name || "Charakter"} · {published.length} veröffentlichte {published.length === 1 ? "Szene" : "Szenen"}</p>
        </div>
        <button className="btn btn-pri" disabled={gen || published.length === 0} onClick={optimize}>
          {gen ? <Loader2 size={16} className="spin" /> : <Send size={16} />}{gen ? "Analysiere…" : "Optimierung generieren"}
        </button>
      </div>

      {published.length === 0 ? (
        <div className="card" style={{ padding: 40, textAlign: "center" }}>
          <TrendingUp size={26} style={{ color: "var(--accent)" }} />
          <h3 style={{ margin: "12px 0 6px" }}>Noch keine Daten</h3>
          <p style={{ color: "var(--muted)", fontSize: 14 }}>Setze in einer Szene den Status auf <b style={{ color: "var(--good)" }}>Veröffentlicht</b> und trage die Zahlen ein. Sobald Daten da sind, analysiert das Gehirn hier, was funktioniert — und schlägt die nächsten Szenen vor.</p>
        </div>
      ) : (
        <div>
          <div className="grid cols-4" style={{ marginBottom: 18 }}>
            <Tile label="Views gesamt" value={fmt(totals.views)} sub={published.length + " Videos"} />
            <Tile label="Ø Engagement" value={(avgER * 100).toFixed(1) + "%"} sub="Likes+Komm.+Saves+Shares / Views" />
            <Tile label="Neue Follower" value={fmt(totals.follows)} sub="summiert" />
            <Tile label="Link-Klicks" value={fmt(totals.clicks)} sub={fmt(totals.saves) + " Saves"} />
          </div>

          {opt && (
            <div className="card-raised fade" style={{ padding: 18, marginBottom: 18 }}>
              <h3 style={{ margin: "0 0 14px", fontSize: 15, display: "flex", alignItems: "center", gap: 8 }}><Target size={15} style={{ color: "var(--accent)" }} /> Empfehlung des Gehirns</h3>
              <div className="grid cols-2">
                <div>
                  <div className="lbl" style={{ color: "var(--good)" }}>Was funktioniert</div>
                  {(opt.works || []).map((w, i) => <div key={i} style={{ fontSize: 13.5, display: "flex", gap: 7, marginBottom: 6 }}><CheckCircle2 size={15} style={{ color: "var(--good)", flexShrink: 0, marginTop: 1 }} />{w}</div>)}
                </div>
                <div>
                  <div className="lbl" style={{ color: "var(--accent2)" }}>Stoppen / ändern</div>
                  {(opt.cut || []).map((w, i) => <div key={i} style={{ fontSize: 13.5, display: "flex", gap: 7, marginBottom: 6 }}><span style={{ color: "var(--accent2)", flexShrink: 0 }}>→</span>{w}</div>)}
                </div>
              </div>
              <div className="lbl" style={{ marginTop: 14 }}>Nächste Szenen</div>
              <div className="grid cols-3">
                {(opt.nextIdeas || []).map((n, i) => (
                  <div key={i} className="card" style={{ padding: 12, background: "var(--panel2)" }}>
                    <div style={{ fontWeight: 600, fontSize: 13.5, marginBottom: 4 }}>{n.title}</div>
                    <div style={{ fontSize: 12, color: "var(--muted)" }}>{n.why}</div>
                  </div>
                ))}
              </div>
              {opt.cadence && <div style={{ marginTop: 14, fontSize: 13, color: "var(--muted)" }}><span style={{ color: "var(--accent)", fontWeight: 600 }}>Frequenz: </span>{opt.cadence}</div>}
            </div>
          )}

          <div className="grid cols-2" style={{ marginBottom: 18 }}>
            <div className="card" style={{ padding: 18 }}>
              <h3 style={{ margin: "0 0 14px", fontSize: 14 }}>Leistung nach Content-Säule</h3>
              {byPillar.length ? <Bars rows={byPillar} max={maxPillar} /> : <p style={{ color: "var(--faint)", fontSize: 13, margin: 0 }}>Keine Säulen-Daten (KPI im Paket setzen).</p>}
            </div>
            <div className="card" style={{ padding: 18 }}>
              <h3 style={{ margin: "0 0 14px", fontSize: 14 }}>Leistung nach Hook-Typ</h3>
              {byHook.length ? <Bars rows={byHook} max={maxHook} /> : <p style={{ color: "var(--faint)", fontSize: 13, margin: 0 }}>Keine Hook-Daten.</p>}
            </div>
          </div>

          <div className="card" style={{ padding: 18 }}>
            <h3 style={{ margin: "0 0 12px", fontSize: 14 }}>Top-Szenen</h3>
            <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
              {topScenes.map((x) => (
                <div key={x.szene.id} className="row" onClick={() => openScene(x.galaxy.id, x.staffel.id, x.szene.id)}>
                  <div style={{ display: "flex", alignItems: "center", gap: 12, minWidth: 0 }}>
                    <Clapperboard size={16} style={{ color: "var(--accent)", flexShrink: 0 }} />
                    <div style={{ minWidth: 0 }}>
                      <div style={{ fontWeight: 600, fontSize: 14, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{x.szene.name}</div>
                      <div style={{ fontSize: 12, color: "var(--muted)" }}>{x.galaxy.name} · {x.staffel.name}</div>
                    </div>
                  </div>
                  <div style={{ display: "flex", gap: 6, alignItems: "center", flexShrink: 0 }}>
                    <span className="pill">{fmt(x.szene.metrics?.views)} Views</span>
                    <span className="pill pill-success">{(engagementRate(x.szene.metrics) * 100).toFixed(1)}%</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
