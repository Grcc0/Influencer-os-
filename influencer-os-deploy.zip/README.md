# Influencer OS — Deployment-Paket

Damit machst du aus dem Prototyp eine **echte App mit Icon auf iPhone und Mac**.

Das Paket hat zwei Teile:

- **`app/`** — das Frontend (die eigentliche App als installierbare PWA). Liegt **schon fertig gebaut** im Ordner `app/dist/` — du kannst ihn direkt hochladen, ohne etwas zu bauen.
- **`backend/`** — ein winziger Server, der deinen **Gemini-Schlüssel sicher server-seitig** hält. Die App spricht nur mit diesem Backend, nie direkt mit dem Schlüssel.

Deine Inhalte (Charaktere, Bücher, Szenen, KPIs) werden **lokal auf dem Gerät** gespeichert (im Browser, via IndexedDB). Pro Gerät getrennt.

---

## Schritt 1 — Kostenlosen Gemini-Schlüssel holen

1. Gehe zu **Google AI Studio** (aistudio.google.com) und melde dich mit einem Google-Konto an.
2. Erstelle einen **API-Key** (Bereich „API keys"). Der Text-Tier ist kostenlos, keine Kreditkarte nötig.
3. Kopiere den Schlüssel — den brauchst du gleich fürs Backend.

---

## Schritt 2 — Backend bereitstellen

Das Backend ist ein Node-Server. Du kannst es **lokal zum Testen** auf dem Mac laufen lassen oder **kostenlos hosten** (nötig, damit dein iPhone es erreicht).

**Lokal testen (Mac):**
1. Im Ordner `backend/`: `npm install`
2. Datei `.env.example` zu `.env` kopieren und `GEMINI_API_KEY=` mit deinem Schlüssel füllen.
3. `npm start` → läuft auf `http://localhost:8787`. Test: im Browser `http://localhost:8787/` öffnen → es sollte `{"ok":true,...}` erscheinen.

**Öffentlich hosten (für das iPhone-Icon):**
Nimm einen Hoster mit Node-Unterstützung (z. B. Render, Railway, Fly — prüfe deren aktuelle Gratis-Stufe).
1. Lade den Inhalt von `backend/` hoch (oder verbinde ein Git-Repo).
2. Build-Command: `npm install` · Start-Command: `npm start`.
3. Setze die Umgebungsvariable **`GEMINI_API_KEY`** (Wert = dein Schlüssel). Optional `GEMINI_MODEL`.
4. Nach dem Deploy bekommst du eine **öffentliche HTTPS-URL** (z. B. `https://…onrender.com`). Notiere sie.

---

## Schritt 3 — Frontend bereitstellen

Die App muss über **HTTPS** erreichbar sein (Pflicht für PWA-Installation; Ausnahme: localhost).

**Einfachster Weg (kein Bauen nötig):**
Lade den fertigen Ordner **`app/dist/`** auf einen beliebigen Static-Host (z. B. Netlify, Cloudflare Pages, GitHub Pages, Vercel). Die meisten geben dir automatisch HTTPS.

**Selbst neu bauen (optional):**
Im Ordner `app/`: `npm install` dann `npm run build` → erzeugt `app/dist/`. Oder lokal ansehen mit `npm run preview`.

---

## Schritt 4 — App mit dem Backend verbinden

1. Öffne deine Frontend-URL im Browser.
2. Oben rechts auf **„Motor"** (Zahnrad) tippen.
3. **Backend-URL** = deine öffentliche Backend-URL aus Schritt 2 (z. B. `https://…onrender.com`).
4. **Motor** = Gemini (gratis · Standard). Claude ist optional und nur nötig, wenn du `ANTHROPIC_API_KEY` im Backend gesetzt hast.

Das oranje Banner „Kein Backend verbunden" verschwindet, sobald die URL gesetzt ist. Dann läuft jede Generierung über deinen kostenlosen Gemini-Tier.

---

## Schritt 5 — Als App installieren

**iPhone (Safari):** Frontend-URL öffnen → **Teilen-Symbol** → **„Zum Home-Bildschirm"**. Fertig — App-Icon wie eine native App.

**Mac (Safari):** URL öffnen → Menü **Ablage** → **„Zum Dock hinzufügen"**. (In Chrome: Adressleiste → **Installieren**.)

---

## Gut zu wissen

- **Kosten:** Gemini-Text-Tier ist gratis. Claude (optional) wäre pro Token kostenpflichtig.
- **Daten:** liegen lokal im Browser/auf dem Gerät. Auf einem anderen Gerät startest du leer (kein Cloud-Sync — bewusst schlank gehalten).
- **„Kein Backend verbunden":** Backend-URL in den Motor-Einstellungen prüfen; Backend erreichbar?
- **Gemini-Fehler / Modell:** Falls Google das Modell umbenennt, setze `GEMINI_MODEL` im Backend auf das aktuelle kostenlose Flash-Modell (siehe Google AI Studio).
- **Sicherheit:** Der Schlüssel liegt nur im Backend (Umgebungsvariable), nie im Frontend. Optional `CORS_ORIGIN` auf deine Frontend-URL beschränken.
